
console.log('my script is loaded');